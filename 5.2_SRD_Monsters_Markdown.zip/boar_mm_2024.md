# Boar

*Medium Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 13 (2d8 + 4)
- **Speed:** 40 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 13 | +1 | +1 |
| DEX | 11 | +0 | +0 |
| CON | 14 | +2 | +2 |
| INT | 2 | -4 | -4 |
| WIS | 9 | -1 | -1 |
| CHA | 5 | -3 | -3 |

- **Senses**: Passive Perception 9
- **CR** 1/4 (XP 50; PB +2)

## Traits

***Bloodied Fury.*** While Bloodied, the boar has Advantage on attack rolls.


## Actions

***Gore.*** *Melee Attack Roll:* +3, reach 5 ft. 4 (1d6 + 1) Piercing damage. If the target is a Medium or smaller creature and the boar moved 20+ feet straight toward it immediately before the hit, the target takes an extra 3 (1d6) Piercing damage and has the Prone condition.

