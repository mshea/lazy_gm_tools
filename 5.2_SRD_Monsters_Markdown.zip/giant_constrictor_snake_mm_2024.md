# Giant Constrictor Snake

*Huge Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 60 (8d12 + 8)
- **Speed:** 30 ft., Swim 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 19 | +4 | +4 |
| DEX | 14 | +2 | +2 |
| CON | 12 | +1 | +1 |
| INT | 1 | -5 | -5 |
| WIS | 10 | +0 | +0 |
| CHA | 3 | -4 | -4 |

- **Skills**: Perception +2
- **Senses**: blindsight 10 ft.; Passive Perception 12
- **CR** 2 (XP 450; PB +2)

## Actions

***Multiattack.*** The snake makes one Bite attack and uses Constrict.

***Bite.*** *Melee Attack Roll:* +6, reach 10 ft. 11 (2d6 + 4) Piercing damage.

***Constrict.*** *Strength Saving Throw*: DC 14, one Large or smaller creature the snake can see within 10 feet. *Failure:*  13 (2d8 + 4) Bludgeoning damage, and the target has the Grappled condition (escape DC 14).

