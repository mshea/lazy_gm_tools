# Commoner

*Medium or Small Humanoid, Neutral*

- **Armor Class:** 10
- **Hit Points:** 4 (1d8)
- **Speed:** 30 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 10 | +0 | +0 |
| DEX | 10 | +0 | +0 |
| CON | 10 | +0 | +0 |
| INT | 10 | +0 | +0 |
| WIS | 10 | +0 | +0 |
| CHA | 10 | +0 | +0 |

- **Gear** Club
- **Senses**: Passive Perception 10
- **Languages**: Common
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Training.*** The commoner has proficiency in one skill of the DM's choice and has Advantage whenever it makes an ability check using that skill.


## Actions

***Club.*** *Melee Attack Roll:* +2, reach 5 ft. 2 (1d4) Bludgeoning damage.

