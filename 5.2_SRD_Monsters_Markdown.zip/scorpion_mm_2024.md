# Scorpion

*Tiny Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 1 (1d4 - 1)
- **Speed:** 10 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 2 | -4 | -4 |
| DEX | 11 | +0 | +0 |
| CON | 8 | -1 | -1 |
| INT | 1 | -5 | -5 |
| WIS | 8 | -1 | -1 |
| CHA | 2 | -4 | -4 |

- **Senses**: blindsight 10 ft.; Passive Perception 9
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Sting.*** *Melee Attack Roll:* +2, reach 5 ft. 1 Piercing damage plus 3 (1d6) Poison damage.

