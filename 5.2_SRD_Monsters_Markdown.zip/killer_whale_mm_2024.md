# Killer Whale

*Huge Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 90 (12d12 + 12)
- **Speed:** 5 ft., Swim 60 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 19 | +4 | +4 |
| DEX | 14 | +2 | +2 |
| CON | 13 | +1 | +1 |
| INT | 3 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +3, Stealth +4
- **Senses**: blindsight 120 ft.; Passive Perception 13
- **CR** 3 (XP 700; PB +2)

## Traits

***Hold Breath.*** The whale can hold its breath for 30 minutes.


## Actions

***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. 21 (5d6 + 4) Piercing damage.

