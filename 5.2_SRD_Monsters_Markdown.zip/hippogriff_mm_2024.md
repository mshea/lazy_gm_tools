# Hippogriff

*Large Monstrosity, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 26 (4d10 + 4)
- **Speed:** 40 ft., Fly 60 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 17 | +3 | +3 |
| DEX | 13 | +1 | +1 |
| CON | 13 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 8 | -1 | -1 |

- **Skills**: Perception +5
- **Senses**: Passive Perception 15
- **CR** 1 (XP 200; PB +2)

## Traits

***Flyby.*** The hippogriff doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.


## Actions

***Multiattack.*** The hippogriff makes two Rend attacks.

***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. 7 (1d8 + 3) Slashing damage.

