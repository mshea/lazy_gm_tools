# Baboon

*Small Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 3 (1d6)
- **Speed:** 30 ft., Climb 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 8 | -1 | -1 |
| DEX | 14 | +2 | +2 |
| CON | 11 | +0 | +0 |
| INT | 4 | -3 | -3 |
| WIS | 12 | +1 | +1 |
| CHA | 6 | -2 | -2 |

- **Senses**: Passive Perception 11
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Pack Tactics.*** The baboon has Advantage on an attack roll against a creature if at least one of the baboon's allies is within 5 feet of the creature and the ally doesn't have the Incapacitated condition.


## Actions

***Bite.*** *Melee Attack Roll:* +1, reach 5 ft. 1 (1d4 - 1) Piercing damage.

