# Azer Sentinel

*Medium Elemental, Lawful Neutral*

- **Armor Class:** 17
- **Hit Points:** 39 (6d8 + 12)
- **Speed:** 30 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 17 | +3 | +3 |
| DEX | 12 | +1 | +1 |
| CON | 15 | +2 | +4 |
| INT | 12 | +1 | +1 |
| WIS | 13 | +1 | +1 |
| CHA | 10 | +0 | +0 |

- **Immunities**: Fire, Poison; Poisoned
- **Senses**: Passive Perception 11
- **Languages**: Primordial (Ignan)
- **CR** 2 (XP 450; PB +2)

## Traits

***Fire Aura.*** At the end of each of the azer's turns, each creature of the azer's choice in a 5-foot Emanation originating from the azer takes 5 (1d10) Fire damage unless the azer has the Incapacitated condition.

***Illumination.*** The azer sheds Bright Light in a 10-foot radius and Dim Light for an additional 10 feet.


## Actions

***Burning Hammer.*** *Melee Attack Roll:* +5, reach 5 ft. 8 (1d10 + 3) Bludgeoning damage plus 3 (1d6) Fire damage.

