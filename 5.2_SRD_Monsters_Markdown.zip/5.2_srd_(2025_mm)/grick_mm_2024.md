# Grick

*Medium Aberration, Unaligned*

- **Armor Class:** 14
- **Hit Points:** 54 (12d8)
- **Speed:** 30 ft., Climb 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 14 | +2 | +2 |
| DEX | 14 | +2 | +2 |
| CON | 11 | +0 | +0 |
| INT | 3 | -4 | -4 |
| WIS | 14 | +2 | +2 |
| CHA | 5 | -3 | -3 |

- **Skills**: Stealth +4
- **Senses**: darkvision 60 ft.; Passive Perception 12
- **CR** 2 (XP 450; PB +2)

## Actions

***Multiattack.*** The grick makes one Beak attack and one Tentacles attack.

***Beak.*** *Melee Attack Roll:* +4, reach 5 ft. 9 (2d6 + 2) Piercing damage.

***Tentacles.*** *Melee Attack Roll:* +4, reach 5 ft. 7 (1d10 + 2) Slashing damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 12) from all four tentacles.

