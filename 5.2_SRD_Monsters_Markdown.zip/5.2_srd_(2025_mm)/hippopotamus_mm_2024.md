# Hippopotamus

*Large Beast, Unaligned*

- **Armor Class:** 14
- **Hit Points:** 82 (11d10 + 22)
- **Speed:** 30 ft., Swim 30 ft.
- **Initiative**: -2 (8)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 21 | +5 | +7 |
| DEX | 7 | -2 | -2 |
| CON | 15 | +2 | +2 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 4 | -3 | -3 |

- **Skills**: Perception +3
- **Senses**: Passive Perception 13
- **CR** 4 (XP 1,100; PB +2)

## Traits

***Hold Breath.*** The hippopotamus can hold its breath for 10 minutes.


## Actions

***Multiattack.*** The hippopotamus makes two Bite attacks.

***Bite.*** *Melee Attack Roll:* +7, reach 5 ft. 16 (2d10 + 5) Piercing damage.

