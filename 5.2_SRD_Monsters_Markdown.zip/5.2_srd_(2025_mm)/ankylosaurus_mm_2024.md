# Ankylosaurus

*Huge Beast (Dinosaur), Unaligned*

- **Armor Class:** 15
- **Hit Points:** 68 (8d12 + 16)
- **Speed:** 30 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 19 | +4 | +6 |
| DEX | 11 | +0 | +0 |
| CON | 15 | +2 | +2 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Senses**: Passive Perception 11
- **CR** 3 (XP 700; PB +2)

## Actions

***Multiattack.*** The ankylosaurus makes two Tail attacks.

***Tail.*** *Melee Attack Roll:* +6, reach 10 ft. 9 (1d10 + 4) Bludgeoning damage. If the target is a Huge or smaller creature, it has the Prone condition.

