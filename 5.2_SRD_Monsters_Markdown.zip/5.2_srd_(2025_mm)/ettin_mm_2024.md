# Ettin

*Large Giant, Chaotic Evil*

- **Armor Class:** 12
- **Hit Points:** 85 (10d10 + 30)
- **Speed:** 40 ft.
- **Initiative**: -1 (9)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 21 | +5 | +5 |
| DEX | 8 | -1 | -1 |
| CON | 17 | +3 | +3 |
| INT | 6 | -2 | -2 |
| WIS | 10 | +0 | +0 |
| CHA | 8 | -1 | -1 |

- **Immunities**: Blinded, Charmed, Deafened, Frightened, Stunned, Unconscious
- **Skills**: Perception +4
- **Gear** Battleaxe, Morningstar
- **Senses**: darkvision 60 ft.; Passive Perception 14
- **Languages**: Giant
- **CR** 4 (XP 1,100; PB +2)

## Actions

***Multiattack.*** The ettin makes one Battleaxe attack and one Morningstar attack.

***Battleaxe.*** *Melee Attack Roll:* +7, reach 5 ft. 14 (2d8 + 5) Slashing damage. If the target is a Large or smaller creature, it has the Prone condition.

***Morningstar.*** *Melee Attack Roll:* +7, reach 5 ft. 14 (2d8 + 5) Piercing damage, and the target has Disadvantage on the next attack roll it makes before the end of its next turn.

