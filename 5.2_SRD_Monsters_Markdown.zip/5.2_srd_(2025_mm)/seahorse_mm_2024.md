# Seahorse

*Small Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 1 (1d4 - 1)
- **Speed:** 5 ft., Swim 20 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 1 | -5 | -5 |
| DEX | 12 | +1 | +1 |
| CON | 8 | -1 | -1 |
| INT | 1 | -5 | -5 |
| WIS | 10 | +0 | +0 |
| CHA | 2 | -4 | -4 |

- **Skills**: Perception +2, Stealth +5
- **Senses**: Passive Perception 12
- **CR** 0 (XP 0)

## Traits

***Water Breathing.*** The seahorse can breathe only underwater.


## Actions

***Bubble Dash.*** While underwater, the seahorse moves up to its Swim Speed without provoking Opportunity Attacks.

