# Draft Horse

*Large Beast, Unaligned*

- **Armor Class:** 10
- **Hit Points:** 15 (2d10 + 4)
- **Speed:** 40 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +4 |
| DEX | 10 | +0 | +0 |
| CON | 15 | +2 | +2 |
| INT | 2 | -4 | -4 |
| WIS | 11 | +0 | +0 |
| CHA | 7 | -2 | -2 |

- **Senses**: Passive Perception 10
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Hooves.*** *Melee Attack Roll:* +6, reach 5 ft. 6 (1d4 + 4) Bludgeoning damage.

