# Giant Eagle

*Large Celestial, Neutral Good*

- **Armor Class:** 13
- **Hit Points:** 26 (4d10 + 4)
- **Speed:** 10 ft., Fly 80 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 16 | +3 | +3 |
| DEX | 17 | +3 | +3 |
| CON | 13 | +1 | +1 |
| INT | 8 | -1 | -1 |
| WIS | 14 | +2 | +2 |
| CHA | 10 | +0 | +0 |

- **Resistances**: Necrotic, Radiant
- **Skills**: Perception +6
- **Senses**: Passive Perception 16
- **Languages**: Celestial; understands Common and Primordial (Auran) but can't speak them
- **CR** 1 (XP 200; PB +2)

## Actions

***Multiattack.*** The eagle makes two Rend attacks.

***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. 5 (1d4 + 3) Slashing damage plus 3 (1d6) Radiant damage.

