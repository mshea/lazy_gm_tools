# Giant Weasel

*Medium Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 9 (2d8)
- **Speed:** 40 ft., Climb 30 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 11 | +0 | +0 |
| DEX | 17 | +3 | +3 |
| CON | 10 | +0 | +0 |
| INT | 4 | -3 | -3 |
| WIS | 12 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Skills**: Acrobatics +5, Perception +3, Stealth +5
- **Senses**: darkvision 60 ft.; Passive Perception 13
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. 5 (1d4 + 3) Piercing damage.

