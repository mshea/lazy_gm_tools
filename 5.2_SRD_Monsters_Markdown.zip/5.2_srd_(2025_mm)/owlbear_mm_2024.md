# Owlbear

*Large Monstrosity, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 59 (7d10 + 21)
- **Speed:** 40 ft., Climb 40 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 20 | +5 | +5 |
| DEX | 12 | +1 | +1 |
| CON | 17 | +3 | +3 |
| INT | 3 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +5
- **Senses**: darkvision 60 ft.; Passive Perception 15
- **CR** 3 (XP 700; PB +2)

## Actions

***Multiattack.*** The owlbear makes two Rend attacks.

***Rend.*** *Melee Attack Roll:* +7, reach 5 ft. 14 (2d8 + 5) Slashing damage.

