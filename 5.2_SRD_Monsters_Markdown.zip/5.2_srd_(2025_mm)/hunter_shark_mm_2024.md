# Hunter Shark

*Large Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 45 (6d10 + 12)
- **Speed:** 5 ft., Swim 40 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +4 |
| DEX | 14 | +2 | +2 |
| CON | 15 | +2 | +2 |
| INT | 1 | -5 | -5 |
| WIS | 10 | +0 | +0 |
| CHA | 4 | -3 | -3 |

- **Skills**: Perception +2
- **Senses**: blindsight 60 ft.; Passive Perception 12
- **CR** 2 (XP 450; PB +2)

## Traits

***Water Breathing.*** The shark can breathe only underwater.


## Actions

***Bite.*** *Melee Attack Roll:* +6 (with Advantage if the target doesn't have all its Hit Points), reach 5 ft. 14 (3d6 + 4) Piercing damage.

