# Rhinoceros

*Large Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 45 (6d10 + 12)
- **Speed:** 40 ft.
- **Initiative**: -1 (9)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 21 | +5 | +5 |
| DEX | 8 | -1 | -1 |
| CON | 15 | +2 | +2 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 6 | -2 | -2 |

- **Senses**: Passive Perception 11
- **CR** 2 (XP 450; PB +2)

## Actions

***Gore.*** *Melee Attack Roll:* +7, reach 5 ft. 14 (2d8 + 5) Piercing damage. If target is a Large or smaller creature and the rhinoceros moved 20+ feet straight toward it immediately before the hit, the target takes an extra 9 (2d8) Piercing damage and has the Prone condition.

