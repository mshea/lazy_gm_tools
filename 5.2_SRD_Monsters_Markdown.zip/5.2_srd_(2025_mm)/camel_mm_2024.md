# Camel

*Large Beast, Unaligned*

- **Armor Class:** 10
- **Hit Points:** 17 (2d10 + 6)
- **Speed:** 50 ft.
- **Initiative**: -1 (9)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 15 | +2 | +2 |
| DEX | 8 | -1 | -1 |
| CON | 17 | +3 | +5 |
| INT | 2 | -4 | -4 |
| WIS | 11 | +0 | +0 |
| CHA | 5 | -3 | -3 |

- **Senses**: darkvision 60 ft.; Passive Perception 10
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. 4 (1d4 + 2) Bludgeoning damage.

