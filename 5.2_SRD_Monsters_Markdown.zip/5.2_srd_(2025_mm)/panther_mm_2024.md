# Panther

*Medium Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 13 (3d8)
- **Speed:** 50 ft., Climb 40 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 14 | +2 | +2 |
| DEX | 16 | +3 | +3 |
| CON | 10 | +0 | +0 |
| INT | 3 | -4 | -4 |
| WIS | 14 | +2 | +2 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +4, Stealth +6
- **Senses**: darkvision 60 ft.; Passive Perception 14
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. 6 (1d6 + 3) Slashing damage.


## Bonus Actions

***Nimble Escape.*** The panther takes the Disengage or Hide action.

