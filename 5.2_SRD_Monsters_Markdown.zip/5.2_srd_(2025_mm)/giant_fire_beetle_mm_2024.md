# Giant Fire Beetle

*Small Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 4 (1d6 + 1)
- **Speed:** 30 ft., Climb 30 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 8 | -1 | -1 |
| DEX | 10 | +0 | +0 |
| CON | 12 | +1 | +1 |
| INT | 1 | -5 | -5 |
| WIS | 7 | -2 | -2 |
| CHA | 3 | -4 | -4 |

- **Resistances**: Fire
- **Senses**: blindsight 30 ft.; Passive Perception 8
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Illumination.*** The beetle sheds Bright Light in a 10-foot radius and Dim Light for an additional 10 feet.


## Actions

***Bite.*** *Melee Attack Roll:* +1, reach 5 ft. 1 Fire damage.

