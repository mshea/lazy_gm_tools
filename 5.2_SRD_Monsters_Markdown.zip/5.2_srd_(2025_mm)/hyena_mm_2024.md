# Hyena

*Medium Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 5 (1d8 + 1)
- **Speed:** 50 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 11 | +0 | +0 |
| DEX | 13 | +1 | +1 |
| CON | 12 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Skills**: Perception +3
- **Senses**: darkvision 60 ft.; Passive Perception 13
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Pack Tactics.*** The hyena has Advantage on an attack roll against a creature if at least one of the hyena's allies is within 5 feet of the creature and the ally doesn't have the Incapacitated condition.


## Actions

***Bite.*** *Melee Attack Roll:* +2, reach 5 ft. 3 (1d6) Piercing damage.

