# Goat

*Medium Beast, Unaligned*

- **Armor Class:** 10
- **Hit Points:** 4 (1d8)
- **Speed:** 40 ft., Climb 30 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 11 | +0 | +2 |
| DEX | 10 | +0 | +0 |
| CON | 11 | +0 | +0 |
| INT | 2 | -4 | -4 |
| WIS | 10 | +0 | +0 |
| CHA | 5 | -3 | -3 |

- **Skills**: Perception +2
- **Senses**: darkvision 60 ft.; Passive Perception 12
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Ram.*** *Melee Attack Roll:* +2, reach 5 ft. 1 Bludgeoning damage, or 2 (1d4) Bludgeoning damage if the goat moved 20+ feet straight toward the target immediately before the hit.

