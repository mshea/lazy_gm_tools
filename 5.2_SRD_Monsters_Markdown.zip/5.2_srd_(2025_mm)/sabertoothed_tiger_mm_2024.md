# Saber-Toothed Tiger

*Large Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 52 (7d10 + 14)
- **Speed:** 40 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +6 |
| DEX | 17 | +3 | +5 |
| CON | 15 | +2 | +2 |
| INT | 3 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 8 | -1 | -1 |

- **Skills**: Perception +5, Stealth +7
- **Senses**: darkvision 60 ft.; Passive Perception 15
- **CR** 2 (XP 450; PB +2)

## Traits

***Running Leap.*** With a 10-foot running start, the tiger can Long Jump up to 25 feet.


## Actions

***Multiattack.*** The tiger makes two Rend attacks.

***Rend.*** *Melee Attack Roll:* +6, reach 5 ft. 11 (2d6 + 4) Slashing damage.


## Bonus Actions

***Nimble Escape.*** The tiger takes the Disengage or Hide action.

