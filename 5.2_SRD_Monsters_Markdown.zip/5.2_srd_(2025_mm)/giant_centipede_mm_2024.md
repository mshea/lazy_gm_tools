# Giant Centipede

*Small Beast, Unaligned*

- **Armor Class:** 14
- **Hit Points:** 9 (2d6 + 2)
- **Speed:** 30 ft., Climb 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 5 | -3 | -3 |
| DEX | 14 | +2 | +2 |
| CON | 12 | +1 | +1 |
| INT | 1 | -5 | -5 |
| WIS | 7 | -2 | -2 |
| CHA | 3 | -4 | -4 |

- **Senses**: blindsight 30 ft.; Passive Perception 8
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. 4 (1d4 + 2) Piercing damage, and the target has the Poisoned condition until the start of the centipede's next turn.

