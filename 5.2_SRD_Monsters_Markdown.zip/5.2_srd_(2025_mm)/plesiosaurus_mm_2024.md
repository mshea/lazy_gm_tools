# Plesiosaurus

*Large Beast (Dinosaur), Unaligned*

- **Armor Class:** 13
- **Hit Points:** 68 (8d10 + 24)
- **Speed:** 20 ft., Swim 40 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +4 |
| DEX | 15 | +2 | +2 |
| CON | 16 | +3 | +3 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Skills**: Perception +3, Stealth +4
- **Senses**: Passive Perception 13
- **CR** 2 (XP 450; PB +2)

## Traits

***Hold Breath.*** The plesiosaurus can hold its breath for 1 hour.


## Actions

***Bite.*** *Melee Attack Roll:* +6, reach 10 ft. 11 (2d6 + 4) Piercing damage.

