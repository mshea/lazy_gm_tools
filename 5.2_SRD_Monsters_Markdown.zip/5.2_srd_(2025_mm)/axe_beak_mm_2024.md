# Axe Beak

*Large Monstrosity, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 19 (3d10 + 3)
- **Speed:** 50 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 14 | +2 | +2 |
| DEX | 12 | +1 | +1 |
| CON | 12 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 10 | +0 | +0 |
| CHA | 5 | -3 | -3 |

- **Senses**: Passive Perception 10
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Beak.*** *Melee Attack Roll:* +4, reach 5 ft. 5 (1d6 + 2) Slashing damage.

