# Bandit Captain

*Medium or Small Humanoid, Neutral*

- **Armor Class:** 15
- **Hit Points:** 52 (8d8 + 16)
- **Speed:** 30 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 15 | +2 | +4 |
| DEX | 16 | +3 | +5 |
| CON | 14 | +2 | +2 |
| INT | 14 | +2 | +2 |
| WIS | 11 | +0 | +2 |
| CHA | 14 | +2 | +2 |

- **Skills**: Athletics +4, Deception +4
- **Gear** Pistol, Scimitar, Studded Leather Armor
- **Senses**: Passive Perception 10
- **Languages**: Common, Thieves' cant
- **CR** 2 (XP 450; PB +2)

## Actions

***Multiattack.*** The bandit makes two attacks, using Scimitar and Pistol in any combination.

***Scimitar.*** *Melee Attack Roll:* +5, reach 5 ft. 6 (1d6 + 3) Slashing damage.

***Pistol.*** *Ranged Attack Roll:* +5, range 30/90 ft. 8 (1d10 + 3) Piercing damage.

