# Badger

*Tiny Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 5 (1d4 + 3)
- **Speed:** 20 ft., Burrow 5 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 10 | +0 | +0 |
| DEX | 11 | +0 | +0 |
| CON | 16 | +3 | +3 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Resistances**: Poison
- **Skills**: Perception +3
- **Senses**: darkvision 30 ft.; Passive Perception 13
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +2, reach 5 ft. 1 Piercing damage.

