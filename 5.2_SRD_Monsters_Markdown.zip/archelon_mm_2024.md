# Archelon

*Huge Beast (Dinosaur), Unaligned*

- **Armor Class:** 17
- **Hit Points:** 90 (12d12 + 12)
- **Speed:** 20 ft., Swim 80 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +4 |
| DEX | 16 | +3 | +3 |
| CON | 13 | +1 | +1 |
| INT | 4 | -3 | -3 |
| WIS | 14 | +2 | +2 |
| CHA | 6 | -2 | -2 |

- **Skills**: Stealth +5
- **Senses**: Passive Perception 12
- **CR** 4 (XP 1,100; PB +2)

## Traits

***Amphibious.*** The archelon can breathe air and water.


## Actions

***Multiattack.*** The archelon makes two Bite attacks.

***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. 14 (3d6 + 4) Piercing damage.

