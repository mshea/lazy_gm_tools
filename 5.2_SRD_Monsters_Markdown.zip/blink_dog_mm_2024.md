# Blink Dog

*Medium Fey, Lawful Good*

- **Armor Class:** 13
- **Hit Points:** 22 (4d8 + 4)
- **Speed:** 40 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 12 | +1 | +1 |
| DEX | 17 | +3 | +3 |
| CON | 12 | +1 | +1 |
| INT | 10 | +0 | +0 |
| WIS | 13 | +1 | +1 |
| CHA | 11 | +0 | +0 |

- **Skills**: Perception +5, Stealth +5
- **Senses**: darkvision 60 ft.; Passive Perception 15
- **Languages**: Understands Elvish and Sylvan but can't speak them
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. 5 (1d4 + 3) Piercing damage.


## Bonus Actions

***Teleport (Recharge 4-6).*** The dog teleports up to 40 feet to an unoccupied space it can see.

