# Warrior Veteran

*Medium or Small Humanoid, Neutral*

- **Armor Class:** 17
- **Hit Points:** 65 (10d8 + 20)
- **Speed:** 30 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 16 | +3 | +3 |
| DEX | 13 | +1 | +1 |
| CON | 14 | +2 | +2 |
| INT | 10 | +0 | +0 |
| WIS | 11 | +0 | +0 |
| CHA | 10 | +0 | +0 |

- **Skills**: Athletics +5, Perception +2
- **Gear** Greatsword, Heavy Crossbow, Splint Armor
- **Senses**: Passive Perception 12
- **Languages**: Common plus one other language
- **CR** 3 (XP 700; PB +2)

## Actions

***Multiattack.*** The warrior makes two Greatsword or Heavy Crossbow attacks.

***Greatsword.*** *Melee Attack Roll:* +5, reach 5 ft. 10 (2d6 + 3) Slashing damage.

***Heavy Crossbow.*** *Ranged Attack Roll:* +3, range 100/400 ft. 12 (2d10 + 1) Piercing damage.

