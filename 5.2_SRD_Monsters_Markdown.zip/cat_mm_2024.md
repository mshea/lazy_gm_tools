# Cat

*Tiny Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 2 (1d4)
- **Speed:** 40 ft., Climb 40 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 3 | -4 | -4 |
| DEX | 15 | +2 | +4 |
| CON | 10 | +0 | +0 |
| INT | 3 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +3, Stealth +4
- **Senses**: darkvision 60 ft.; Passive Perception 13
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Jumper.*** The cat's jump distance is determined using its Dexterity rather than its Strength.


## Actions

***Scratch.*** *Melee Attack Roll:* +4, reach 5 ft. 1 Slashing damage.

