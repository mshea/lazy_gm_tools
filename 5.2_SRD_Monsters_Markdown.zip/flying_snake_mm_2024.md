# Flying Snake

*Tiny Monstrosity, Unaligned*

- **Armor Class:** 14
- **Hit Points:** 5 (2d4)
- **Speed:** 30 ft., Fly 60 ft., Swim 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 4 | -3 | -3 |
| DEX | 15 | +2 | +2 |
| CON | 11 | +0 | +0 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Senses**: blindsight 10 ft.; Passive Perception 11
- **CR** 1/8 (XP 25; PB +2)

## Traits

***Flyby.*** The snake doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.


## Actions

***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. 1 Piercing damage plus 5 (2d4) Poison damage.

