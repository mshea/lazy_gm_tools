# Ape

*Medium Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 19 (3d8 + 6)
- **Speed:** 30 ft., Climb 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 16 | +3 | +3 |
| DEX | 14 | +2 | +2 |
| CON | 14 | +2 | +2 |
| INT | 6 | -2 | -2 |
| WIS | 12 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Skills**: Athletics +5, Perception +3
- **Senses**: Passive Perception 13
- **CR** 1/2 (XP 100; PB +2)

## Actions

***Multiattack.*** The ape makes two Fist attacks.

***Fist.*** *Melee Attack Roll:* +5, reach 5 ft. 5 (1d4 + 3) Bludgeoning damage.

***Rock (Recharge 6).*** *Ranged Attack Roll:* +5, range 25/50 ft. 10 (2d6 + 3) Bludgeoning damage.

