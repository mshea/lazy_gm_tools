# Minotaur of Baphomet

*Large Monstrosity, Chaotic Evil*

- **Armor Class:** 14
- **Hit Points:** 85 (10d10 + 30)
- **Speed:** 40 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +4 |
| DEX | 11 | +0 | +0 |
| CON | 16 | +3 | +3 |
| INT | 6 | -2 | -2 |
| WIS | 16 | +3 | +3 |
| CHA | 9 | -1 | -1 |

- **Skills**: Perception +7, Survival +7
- **Senses**: darkvision 60 ft.; Passive Perception 17
- **Languages**: Abyssal
- **CR** 3 (XP 700; PB +2)

## Actions

***Abyssal Glaive.*** *Melee Attack Roll:* +6, reach 10 ft. 10 (1d12 + 4) Slashing damage plus 10 (3d6) Necrotic damage.

***Gore (Recharge 5-6).*** *Melee Attack Roll:* +6, reach 5 ft. 18 (4d6 + 4) Piercing damage. If the target is a Large or smaller creature and the minotaur moved 10+ feet straight toward it immediately before the hit, the target takes an extra 10 (3d6) Piercing damage and has the Prone condition.

