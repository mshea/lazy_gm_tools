# Wyvern

*Large Dragon, Unaligned*

- **Armor Class:** 14
- **Hit Points:** 127 (15d10 + 45)
- **Speed:** 30 ft., Fly 80 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 19 | +4 | +4 |
| DEX | 10 | +0 | +0 |
| CON | 16 | +3 | +3 |
| INT | 5 | -3 | -3 |
| WIS | 12 | +1 | +1 |
| CHA | 6 | -2 | -2 |

- **Skills**: Perception +4
- **Senses**: darkvision 120 ft.; Passive Perception 14
- **CR** 6 (XP 2,300; PB +3)

## Actions

***Multiattack.*** The wyvern makes one Bite attack and one Sting attack.

***Bite.*** *Melee Attack Roll:* +7, reach 5 ft. 13 (2d8 + 4) Piercing damage.

***Sting.*** *Melee Attack Roll:* +7, reach 10 ft. 11 (2d6 + 4) Piercing damage plus 24 (7d6) Poison damage, and the target has the Poisoned condition until the start of the wyvern's next turn.

