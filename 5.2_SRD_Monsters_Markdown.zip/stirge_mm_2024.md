# Stirge

*Tiny Monstrosity, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 5 (2d4)
- **Speed:** 10 ft., Fly 40 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 4 | -3 | -3 |
| DEX | 16 | +3 | +3 |
| CON | 11 | +0 | +0 |
| INT | 2 | -4 | -4 |
| WIS | 8 | -1 | -1 |
| CHA | 6 | -2 | -2 |

- **Senses**: darkvision 60 ft.; Passive Perception 9
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Proboscis.*** *Melee Attack Roll:* +5, reach 5 ft. 6 (1d6 + 3) Piercing damage, and the stirge attaches to the target. While attached, the stirge can't make Proboscis attacks, and the target takes 5 (2d4) Necrotic damage at the start of each of the stirge's turns.
The stirge can detach itself by spending 5 feet of its movement. The target or a creature within 5 feet of it can detach the stirge as an action.

