# Owl

*Tiny Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 1 (1d4 - 1)
- **Speed:** 5 ft., Fly 60 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 3 | -4 | -4 |
| DEX | 13 | +1 | +1 |
| CON | 8 | -1 | -1 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +5, Stealth +5
- **Senses**: darkvision 120 ft.; Passive Perception 15
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Flyby.*** The owl doesn't provoke Opportunity Attacks when it flies out of an enemy's reach.


## Actions

***Talons.*** *Melee Attack Roll:* +3, reach 5 ft. 1 Slashing damage.

