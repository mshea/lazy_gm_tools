# Pteranodon

*Medium Beast (Dinosaur), Unaligned*

- **Armor Class:** 13
- **Hit Points:** 13 (3d8)
- **Speed:** 10 ft., Fly 60 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 12 | +1 | +1 |
| DEX | 15 | +2 | +2 |
| CON | 10 | +0 | +0 |
| INT | 2 | -4 | -4 |
| WIS | 9 | -1 | -1 |
| CHA | 5 | -3 | -3 |

- **Skills**: Perception +1
- **Senses**: Passive Perception 11
- **CR** 1/4 (XP 50; PB +2)

## Traits

***Flyby.*** The pteranodon doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.


## Actions

***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. 6 (1d8 + 2) Piercing damage.

