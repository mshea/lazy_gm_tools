# Lizard

*Tiny Beast, Unaligned*

- **Armor Class:** 10
- **Hit Points:** 2 (1d4)
- **Speed:** 20 ft., Climb 20 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 2 | -4 | -4 |
| DEX | 11 | +0 | +0 |
| CON | 10 | +0 | +0 |
| INT | 1 | -5 | -5 |
| WIS | 8 | -1 | -1 |
| CHA | 3 | -4 | -4 |

- **Senses**: darkvision 30 ft.; Passive Perception 9
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Spider Climb.*** The lizard can climb difficult surfaces, including along ceilings, without needing to make an ability check.


## Actions

***Bite.*** *Melee Attack Roll:* +2, reach 5 ft. 1 Piercing damage.

