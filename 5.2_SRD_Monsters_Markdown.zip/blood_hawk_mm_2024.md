# Blood Hawk

*Small Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 7 (2d6)
- **Speed:** 10 ft., Fly 60 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 6 | -2 | -2 |
| DEX | 14 | +2 | +2 |
| CON | 10 | +0 | +0 |
| INT | 3 | -4 | -4 |
| WIS | 14 | +2 | +2 |
| CHA | 5 | -3 | -3 |

- **Skills**: Perception +6
- **Senses**: Passive Perception 16
- **CR** 1/8 (XP 25; PB +2)

## Traits

***Pack Tactics.*** The hawk has Advantage on an attack roll against a creature if at least one of the hawk's allies is within 5 feet of the creature and the ally doesn't have the Incapacitated condition.


## Actions

***Beak.*** *Melee Attack Roll:* +4, reach 5 ft. 4 (1d4 + 2) Piercing damage, or 6 (1d8 + 2) Piercing damage if the target is Bloodied.

