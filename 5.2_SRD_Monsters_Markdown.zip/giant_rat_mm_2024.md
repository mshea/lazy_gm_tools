# Giant Rat

*Small Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 7 (2d6)
- **Speed:** 30 ft., Climb 30 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 7 | -2 | -2 |
| DEX | 16 | +3 | +5 |
| CON | 11 | +0 | +0 |
| INT | 2 | -4 | -4 |
| WIS | 10 | +0 | +0 |
| CHA | 4 | -3 | -3 |

- **Skills**: Perception +2
- **Senses**: darkvision 60 ft.; Passive Perception 12
- **CR** 1/8 (XP 25; PB +2)

## Traits

***Pack Tactics.*** The rat has Advantage on an attack roll against a creature if at least one of the rat's allies is within 5 feet of the creature and the ally doesn't have the Incapacitated condition.


## Actions

***Bite.*** *Melee Attack Roll:* +5, reach 5 feet. 5 (1d4 + 3) Piercing damage.

