# Giant Badger

*Medium Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 15 (2d8 + 6)
- **Speed:** 30 ft., Burrow 10 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 13 | +1 | +1 |
| DEX | 10 | +0 | +0 |
| CON | 17 | +3 | +3 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Resistances**: Poison
- **Skills**: Perception +3
- **Senses**: darkvision 60 ft.; Passive Perception 13
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +3, reach 5 ft. 6 (2d4 + 1) Piercing damage.

