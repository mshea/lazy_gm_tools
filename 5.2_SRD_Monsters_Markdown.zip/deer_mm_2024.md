# Deer

*Medium Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 4 (1d8)
- **Speed:** 50 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 11 | +0 | +0 |
| DEX | 16 | +3 | +3 |
| CON | 11 | +0 | +0 |
| INT | 2 | -4 | -4 |
| WIS | 14 | +2 | +2 |
| CHA | 5 | -3 | -3 |

- **Skills**: Perception +4
- **Senses**: darkvision 60 ft.; Passive Perception 14
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Agile.*** The deer doesn't provoke an Opportunity Attack when it moves out of an enemy's reach.


## Actions

***Ram.*** *Melee Attack Roll:* +2, reach 5 ft. 2 (1d4) Bludgeoning damage.

