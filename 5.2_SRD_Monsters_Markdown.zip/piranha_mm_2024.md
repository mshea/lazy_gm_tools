# Piranha

*Tiny Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 1 (1d4 - 1)
- **Speed:** 5 ft., Swim 40 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 2 | -4 | -4 |
| DEX | 16 | +3 | +3 |
| CON | 9 | -1 | -1 |
| INT | 1 | -5 | -5 |
| WIS | 7 | -2 | -2 |
| CHA | 2 | -4 | -4 |

- **Senses**: darkvision 60 ft.; Passive Perception 8
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Water Breathing.*** The piranha can breathe only underwater.


## Actions

***Bite.*** *Melee Attack Roll:* +5 (with Advantage if the target doesn't have all its Hit Points), reach 5 ft. 1 Piercing damage.

