# Manticore

*Large Monstrosity, Lawful Evil*

- **Armor Class:** 14
- **Hit Points:** 68 (8d10 + 24)
- **Speed:** 30 ft., Fly 50 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 17 | +3 | +3 |
| DEX | 16 | +3 | +3 |
| CON | 17 | +3 | +3 |
| INT | 7 | -2 | -2 |
| WIS | 12 | +1 | +1 |
| CHA | 8 | -1 | -1 |

- **Senses**: darkvision 60 ft.; Passive Perception 11
- **Languages**: Common
- **CR** 3 (XP 700; PB +2)

## Actions

***Multiattack.*** The manticore makes three attacks, using Rend or Tail Spike in any combination.

***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. 7 (1d8 + 3) Slashing damage.

***Tail Spike.*** *Ranged Attack Roll:* +5, range 100/200 ft. 7 (1d8 + 3) Piercing damage.

