# Tiger

*Large Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 30 (4d10 + 8)
- **Speed:** 40 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 17 | +3 | +3 |
| DEX | 16 | +3 | +3 |
| CON | 14 | +2 | +2 |
| INT | 3 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 8 | -1 | -1 |

- **Skills**: Perception +3, Stealth +7
- **Senses**: darkvision 60 ft.; Passive Perception 13
- **CR** 1 (XP 200; PB +2)

## Actions

***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. 10 (2d6 + 3) Slashing damage. If the target is a Large or smaller creature, it has the Prone condition.


## Bonus Actions

***Nimble Escape.*** The tiger takes the Disengage or Hide action.

