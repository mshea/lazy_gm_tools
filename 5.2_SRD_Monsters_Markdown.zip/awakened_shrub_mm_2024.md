# Awakened Shrub

*Small Plant, Neutral*

- **Armor Class:** 9
- **Hit Points:** 10 (3d6)
- **Speed:** 20 ft.
- **Initiative**: -1 (9)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 3 | -4 | -4 |
| DEX | 8 | -1 | -1 |
| CON | 11 | +0 | +0 |
| INT | 10 | +0 | +0 |
| WIS | 10 | +0 | +0 |
| CHA | 6 | -2 | -2 |

- **Vulnerabilities**: Fire
- **Resistances**: Piercing
- **Senses**: Passive Perception 10
- **Languages**: Common plus one other language
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Rake.*** *Melee Attack Roll:* +1, reach 5 ft. 1 Slashing damage.

