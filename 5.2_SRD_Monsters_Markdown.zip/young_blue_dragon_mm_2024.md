# Young Blue Dragon

*Large Dragon (Chromatic), Lawful Evil*

- **Armor Class:** 18
- **Hit Points:** 152 (16d10 + 64)
- **Speed:** 40 ft., Burrow 20 ft., Fly 80 ft.
- **Initiative**: +4 (14)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 21 | +5 | +5 |
| DEX | 10 | +0 | +4 |
| CON | 19 | +4 | +4 |
| INT | 14 | +2 | +2 |
| WIS | 13 | +1 | +5 |
| CHA | 17 | +3 | +3 |

- **Immunities**: Lightning
- **Skills**: Perception +9, Stealth +4
- **Senses**: blindsight 30 ft., darkvision 120 ft.; Passive Perception 19
- **Languages**: Common, Draconic
- **CR** 9 (XP 5,000; PB +4)

## Actions

***Multiattack.*** The dragon makes three Rend attacks.

***Rend.*** *Melee Attack Roll:* +9, reach 10 ft. 12 (2d6 + 5) Slashing damage plus 5 (1d10) Lightning damage.

***Lightning Breath (Recharge 5-6).*** *Dexterity Saving Throw*: DC 16, each creature in a 60-foot-long, 5-foot-wide Line. *Failure:*  55 (10d10) Lightning damage. *Success:*  Half damage.

