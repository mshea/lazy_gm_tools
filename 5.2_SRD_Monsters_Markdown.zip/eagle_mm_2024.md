# Eagle

*Small Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 4 (1d6 + 1)
- **Speed:** 10 ft., Fly 60 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 6 | -2 | -2 |
| DEX | 15 | +2 | +2 |
| CON | 12 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 14 | +2 | +2 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +6
- **Senses**: Passive Perception 16
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Talons.*** *Melee Attack Roll:* +4, reach 5 feet. 4 (1d4 + 2) Slashing damage.

