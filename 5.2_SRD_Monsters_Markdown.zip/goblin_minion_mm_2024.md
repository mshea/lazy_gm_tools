# Goblin Minion

*Small Fey (Goblinoid), Chaotic Neutral*

- **Armor Class:** 12
- **Hit Points:** 7 (2d6)
- **Speed:** 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 8 | -1 | -1 |
| DEX | 15 | +2 | +2 |
| CON | 10 | +0 | +0 |
| INT | 10 | +0 | +0 |
| WIS | 8 | -1 | -1 |
| CHA | 8 | -1 | -1 |

- **Skills**: Stealth +6
- **Gear** Dagger x 3
- **Senses**: darkvision 60 ft.; Passive Perception 9
- **Languages**: Common, Goblin
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Dagger.*** *Melee or Ranged Attack Roll:* +4, reach 5 ft. or range 20/60 ft. 4 (1d4 + 2) Piercing damage.


## Bonus Actions

***Nimble Escape.*** The goblin takes the Disengage or Hide action.

