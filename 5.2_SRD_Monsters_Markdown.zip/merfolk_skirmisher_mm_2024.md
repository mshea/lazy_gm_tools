# Merfolk Skirmisher

*Medium Elemental, Neutral*

- **Armor Class:** 11
- **Hit Points:** 11 (2d8 + 2)
- **Speed:** 10 ft., Swim 40 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 10 | +0 | +0 |
| DEX | 13 | +1 | +1 |
| CON | 12 | +1 | +1 |
| INT | 11 | +0 | +0 |
| WIS | 14 | +2 | +2 |
| CHA | 12 | +1 | +1 |

- **Senses**: Passive Perception 12
- **Languages**: Common, Primordial (Aquan)
- **CR** 1/8 (XP 25; PB +2)

## Traits

***Amphibious.*** The merfolk can breathe air and water.


## Actions

***Ocean Spear.*** *Melee or Ranged Attack Roll:* +2, reach 5 ft. or range 20/60 ft. 3 (1d6) Piercing damage plus 2 (1d4) Cold damage. If the target is a creature, its Speed decreases by 10 feet until the end of its next turn. HitomThe spear magically returns to the merfolk's hand immediately after a ranged attack.

