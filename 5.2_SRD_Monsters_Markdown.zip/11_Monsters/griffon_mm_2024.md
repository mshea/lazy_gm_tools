# Griffon

*Large Monstrosity, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 59 (7d10 + 21)
- **Speed:** 30 ft., Fly 80 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +4 |
| DEX | 15 | +2 | +2 |
| CON | 16 | +3 | +3 |
| INT | 2 | -4 | -4 |
| WIS | 13 | +1 | +1 |
| CHA | 8 | -1 | -1 |

- **Skills**: Perception +5
- **Senses**: darkvision 60 ft.; Passive Perception 15
- **CR** 2 (XP 450; PB +2)

## Actions

***Multiattack.*** The griffon makes two Rend attacks.

***Rend.*** *Melee Attack Roll:* +6, reach 5 ft. 8 (1d8 + 4) Piercing damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 14) from both of the griffon's front claws.

