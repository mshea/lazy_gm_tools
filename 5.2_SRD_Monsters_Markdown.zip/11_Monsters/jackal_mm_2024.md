# Jackal

*Small Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 3 (1d6)
- **Speed:** 40 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 8 | -1 | -1 |
| DEX | 15 | +2 | +2 |
| CON | 11 | +0 | +0 |
| INT | 3 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 6 | -2 | -2 |

- **Skills**: Perception +5, Stealth +4
- **Senses**: darkvision 90 ft.; Passive Perception 15
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +1, reach 5 ft. 1 (1d4 - 1) Piercing damage.

