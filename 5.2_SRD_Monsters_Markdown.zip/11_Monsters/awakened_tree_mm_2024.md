# Awakened Tree

*Huge Plant, Neutral*

- **Armor Class:** 13
- **Hit Points:** 59 (7d12 + 14)
- **Speed:** 20 ft.
- **Initiative**: -2 (8)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 19 | +4 | +4 |
| DEX | 6 | -2 | -2 |
| CON | 15 | +2 | +2 |
| INT | 10 | +0 | +0 |
| WIS | 10 | +0 | +0 |
| CHA | 7 | -2 | -2 |

- **Vulnerabilities**: Fire
- **Resistances**: Bludgeoning, Piercing
- **Senses**: Passive Perception 10
- **Languages**: Common plus one other language
- **CR** 2 (XP 450; PB +2)

## Actions

***Slam.*** *Melee Attack Roll:* +6, reach 10 ft. 13 (2d8 + 4) Bludgeoning damage.

