# Gargoyle

*Medium Elemental, Chaotic Evil*

- **Armor Class:** 15
- **Hit Points:** 67 (9d8 + 27)
- **Speed:** 30 ft., Fly 60 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 15 | +2 | +2 |
| DEX | 11 | +0 | +0 |
| CON | 16 | +3 | +3 |
| INT | 6 | -2 | -2 |
| WIS | 11 | +0 | +0 |
| CHA | 7 | -2 | -2 |

- **Immunities**: Poison; Exhaustion, Petrified, Poisoned
- **Skills**: Stealth +4
- **Senses**: darkvision 60 ft.; Passive Perception 10
- **Languages**: Primordial (Terran)
- **CR** 2 (XP 450; PB +2)

## Traits

***Flyby.*** The gargoyle doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.


## Actions

***Multiattack.*** The gargoyle makes two Claw attacks.

***Claw.*** *Melee Attack Roll:* +4, reach 5 ft. 7 (2d4 + 2) Slashing damage.

