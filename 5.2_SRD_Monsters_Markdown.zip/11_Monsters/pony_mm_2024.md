# Pony

*Medium Beast, Unaligned*

- **Armor Class:** 10
- **Hit Points:** 11 (2d8 + 2)
- **Speed:** 40 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 15 | +2 | +4 |
| DEX | 10 | +0 | +0 |
| CON | 13 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 11 | +0 | +0 |
| CHA | 7 | -2 | -2 |

- **Senses**: Passive Perception 10
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Hooves.*** *Melee Attack Roll:* +4, reach 5 ft. 4 (1d4 + 2) Bludgeoning damage.

