# Animated Armor

*Medium Construct, Unaligned*

- **Armor Class:** 18
- **Hit Points:** 33 (6d8 + 6)
- **Speed:** 25 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 14 | +2 | +2 |
| DEX | 11 | +0 | +0 |
| CON | 13 | +1 | +1 |
| INT | 1 | -5 | -5 |
| WIS | 3 | -4 | -4 |
| CHA | 1 | -5 | -5 |

- **Immunities**: Poison, Psychic; Charmed, Deafened, Exhaustion, Frightened, Paralyzed, Petrified, Poisoned
- **Senses**: blindsight 60 ft.; Passive Perception 6
- **CR** 1 (XP 200; PB +2)

## Actions

***Multiattack.*** The armor makes two Slam attacks.

***Slam.*** *Melee Attack Roll:* +4, reach 5 ft. 5 (1d6 + 2) Bludgeoning damage.

