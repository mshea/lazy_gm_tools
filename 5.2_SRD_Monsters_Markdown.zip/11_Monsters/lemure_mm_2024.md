# Lemure

*Medium Fiend (Devil), Lawful Evil*

- **Armor Class:** 9
- **Hit Points:** 9 (2d8)
- **Speed:** 20 ft.
- **Initiative**: -3 (7)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 10 | +0 | +0 |
| DEX | 5 | -3 | -3 |
| CON | 11 | +0 | +0 |
| INT | 1 | -5 | -5 |
| WIS | 11 | +0 | +0 |
| CHA | 3 | -4 | -4 |

- **Resistances**: Cold
- **Immunities**: Fire, Poison; Charmed, Frightened, Poisoned
- **Senses**: darkvision 120 ft. (unimpeded by magical darkness); Passive Perception 10
- **Languages**: Understands Infernal but can't speak
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Hellish Restoration.*** If the lemure dies in the Nine Hells, it revives with all its Hit Points in 1d10 days unless it is killed by a creature under the effects of a *Bless* spell or its remains are sprinkled with Holy Water.


## Actions

***Vile Slime.*** *Melee Attack Roll:* +2, reach 5 ft. 2 (1d4) Poison damage.

