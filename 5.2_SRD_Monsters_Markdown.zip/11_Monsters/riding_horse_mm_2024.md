# Riding Horse

*Large Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 13 (2d10 + 2)
- **Speed:** 60 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 16 | +3 | +3 |
| DEX | 13 | +1 | +1 |
| CON | 12 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 11 | +0 | +0 |
| CHA | 7 | -2 | -2 |

- **Senses**: Passive Perception 10
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Hooves.*** *Melee Attack Roll:* +5, reach 5 ft. 7 (1d8 + 3) Bludgeoning damage.

