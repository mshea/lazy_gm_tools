# Giant Venomous Snake

*Medium Beast, Unaligned*

- **Armor Class:** 14
- **Hit Points:** 11 (2d8 + 2)
- **Speed:** 40 ft., Swim 40 ft.
- **Initiative**: +4 (14)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 10 | +0 | +0 |
| DEX | 18 | +4 | +4 |
| CON | 13 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 10 | +0 | +0 |
| CHA | 3 | -4 | -4 |

- **Skills**: Perception +2
- **Senses**: blindsight 10 ft.; Passive Perception 12
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +6, reach 10 ft. 6 (1d4 + 4) Piercing damage plus 4 (1d8) Poison damage.

