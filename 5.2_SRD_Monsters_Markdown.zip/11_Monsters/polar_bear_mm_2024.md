# Polar Bear

*Large Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 42 (5d10 + 15)
- **Speed:** 40 ft., Swim 40 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 20 | +5 | +5 |
| DEX | 14 | +2 | +2 |
| CON | 16 | +3 | +3 |
| INT | 2 | -4 | -4 |
| WIS | 13 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Resistances**: Cold
- **Skills**: Perception +5, Stealth +4
- **Senses**: darkvision 60 ft.; Passive Perception 15
- **CR** 2 (XP 450; PB +2)

## Actions

***Multiattack.*** The bear makes two Rend attacks.

***Rend.*** *Melee Attack Roll:* +7, reach 5 ft. 9 (1d8 + 5) Slashing damage.

