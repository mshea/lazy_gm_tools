# Berserker

*Small Humanoid, Neutral*

- **Armor Class:** 13
- **Hit Points:** 67 (9d8 + 27)
- **Speed:** 30 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 16 | +3 | +3 |
| DEX | 12 | +1 | +1 |
| CON | 17 | +3 | +3 |
| INT | 9 | -1 | -1 |
| WIS | 11 | +0 | +0 |
| CHA | 9 | -1 | -1 |

- **Gear** Greataxe, Hide Armor
- **Senses**: Passive Perception 10
- **Languages**: Common
- **CR** 2 (XP 450; PB +2)

## Traits

***Bloodied Frenzy.*** While Bloodied, the berserker has Advantage on attack rolls and saving throws.


## Actions

***Greataxe.*** *Melee Attack Roll:* +5, reach 5 ft. 9 (1d12 + 3) Slashing damage.

