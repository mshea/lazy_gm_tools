# Hawk

*Small Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 1 (1d4 - 1)
- **Speed:** 10 ft., Fly 60 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 5 | -3 | -3 |
| DEX | 16 | +3 | +3 |
| CON | 8 | -1 | -1 |
| INT | 2 | -4 | -4 |
| WIS | 14 | +2 | +2 |
| CHA | 6 | -2 | -2 |

- **Skills**: Perception +6
- **Senses**: Passive Perception 16
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Talons.*** *Melee Attack Roll:* +5, reach 5 ft. 1 Slashing damage.

