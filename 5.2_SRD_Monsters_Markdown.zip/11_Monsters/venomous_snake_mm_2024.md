# Venomous Snake

*Small Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 5 (2d4)
- **Speed:** 30 ft., Swim 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 2 | -4 | -4 |
| DEX | 15 | +2 | +2 |
| CON | 11 | +0 | +0 |
| INT | 1 | -5 | -5 |
| WIS | 10 | +0 | +0 |
| CHA | 3 | -4 | -4 |

- **Senses**: blindsight 10 ft.; Passive Perception 10
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. 4 (1d4 + 2) Piercing damage plus 3 (1d6) Poison damage.

