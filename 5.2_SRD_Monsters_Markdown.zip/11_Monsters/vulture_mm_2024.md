# Vulture

*Medium Beast, Unaligned*

- **Armor Class:** 10
- **Hit Points:** 5 (1d8 + 1)
- **Speed:** 10 ft., Fly 50 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 7 | -2 | -2 |
| DEX | 10 | +0 | +0 |
| CON | 13 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 4 | -3 | -3 |

- **Skills**: Perception +3
- **Senses**: Passive Perception 13
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Pack Tactics.*** The vulture has Advantage on an attack roll against a creature if at least one of the vulture's allies is within 5 feet of the creature and the ally doesn't have the Incapacitated condition.


## Actions

***Beak.*** *Melee Attack Roll:* +2, reach 5 ft. 2 (1d4) Piercing damage.

