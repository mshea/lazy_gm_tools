# Spy

*Small Humanoid, Neutral*

- **Armor Class:** 12
- **Hit Points:** 27 (6d8)
- **Speed:** 30 ft., Climb 30 ft.
- **Initiative**: +4 (14)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 10 | +0 | +0 |
| DEX | 15 | +2 | +2 |
| CON | 10 | +0 | +0 |
| INT | 12 | +1 | +1 |
| WIS | 14 | +2 | +2 |
| CHA | 16 | +3 | +3 |

- **Skills**: Deception +5, Insight +4, Investigation +5, Perception +6, Sleight of hand +4, Stealth +6
- **Gear** Hand Crossbow, Shortsword, Thieves' Tools
- **Senses**: Passive Perception 16
- **Languages**: Common plus one other language
- **CR** 1 (XP 200; PB +2)

## Actions

***Shortsword.*** *Melee Attack Roll:* +4, reach 5 ft. 5 (1d6 + 2) Piercing damage plus 7 (2d6) Poison damage.

***Hand Crossbow.*** *Ranged Attack Roll:* +4, range 30/120 ft. 5 (1d6 + 2) Piercing damage plus 7 (2d6) Poison damage.


## Bonus Actions

***Cunning Action.*** The spy takes the Dash, Disengage, or Hide action.

