# Giant Boar

*Large Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 42 (5d10 + 15)
- **Speed:** 40 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 17 | +3 | +5 |
| DEX | 10 | +0 | +0 |
| CON | 16 | +3 | +3 |
| INT | 2 | -4 | -4 |
| WIS | 7 | -2 | -2 |
| CHA | 5 | -3 | -3 |

- **Senses**: Passive Perception 8
- **CR** 2 (XP 450; PB +2)

## Traits

***Bloodied Fury.*** The boar has Advantage on melee attack rolls while it is Bloodied.


## Actions

***Gore.*** *Melee Attack Roll:* +5, reach 5 ft. 10 (2d6 + 3) Piercing damage. If the target is a Large or smaller creature and the boar moved 20+ feet straight toward it immediately before the hit, the target takes an extra 7 (2d6) Piercing damage and has the Prone condition.

