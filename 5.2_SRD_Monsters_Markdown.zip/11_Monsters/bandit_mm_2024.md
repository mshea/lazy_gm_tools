# Bandit

*Small Humanoid, Neutral*

- **Armor Class:** 12
- **Hit Points:** 11 (2d8 + 2)
- **Speed:** 30 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 11 | +0 | +0 |
| DEX | 12 | +1 | +1 |
| CON | 12 | +1 | +1 |
| INT | 10 | +0 | +0 |
| WIS | 10 | +0 | +0 |
| CHA | 10 | +0 | +0 |

- **Gear** Leather Armor, Light Crossbow, Scimitar
- **Senses**: Passive Perception 10
- **Languages**: Common, Thieves' cant
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Scimitar.*** *Melee Attack Roll:* +3, reach 5 ft. 4 (1d6 + 1) Slashing damage.

***Light Crossbow.*** *Ranged Attack Roll:* +3, range 80/320 ft. 5 (1d8 + 1) Piercing damage.

