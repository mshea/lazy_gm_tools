# Young Red Dragon

*Large Dragon (Chromatic), Chaotic Evil*

- **Armor Class:** 18
- **Hit Points:** 178 (17d10 + 85)
- **Speed:** 40 ft., Climb 40 ft., Fly 80 ft.
- **Initiative**: +4 (14)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 23 | +6 | +6 |
| DEX | 10 | +0 | +4 |
| CON | 21 | +5 | +5 |
| INT | 14 | +2 | +2 |
| WIS | 11 | +0 | +4 |
| CHA | 19 | +4 | +4 |

- **Immunities**: Fire
- **Skills**: Perception +8, Stealth +4
- **Senses**: blindsight 30 ft., darkvision 120 ft.; Passive Perception 18
- **Languages**: Common, Draconic
- **CR** 10 (XP 5,900; PB +4)

## Actions

***Multiattack.*** The dragon makes three Rend attacks.

***Rend.*** *Melee Attack Roll:* +10, reach 10 ft. 13 (2d6 + 6) Slashing damage plus 3 (1d6) Fire damage.

***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw*: DC 17, each creature in a 30-foot Cone. *Failure:*  56 (16d6) Fire damage. *Success:*  Half damage.

