# Pegasus

*Large Celestial, Chaotic Good*

- **Armor Class:** 12
- **Hit Points:** 59 (7d10 + 21)
- **Speed:** 60 ft., Fly 90 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 18 | +4 | +4 |
| DEX | 15 | +2 | +4 |
| CON | 16 | +3 | +5 |
| INT | 10 | +0 | +0 |
| WIS | 15 | +2 | +4 |
| CHA | 13 | +1 | +3 |

- **Skills**: Perception +6
- **Senses**: Passive Perception 16
- **Languages**: Understands Celestial, Common, Elvish, And Sylvan but can't speak
- **CR** 2 (XP 450; PB +2)

## Actions

***Hooves.*** *Melee Attack Roll:* +6, reach 5 ft. 7 (1d6 + 4) Bludgeoning damage plus 5 (2d4) Radiant damage.

