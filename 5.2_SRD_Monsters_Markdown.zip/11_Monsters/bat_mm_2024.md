# Bat

*Small Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 1 (1d4 - 1)
- **Speed:** 5 ft., Fly 30 ft.
- **Initiative**: +2 (12)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 2 | -4 | -4 |
| DEX | 15 | +2 | +2 |
| CON | 8 | -1 | -1 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 4 | -3 | -3 |

- **Senses**: blindsight 60 ft.; Passive Perception 11
- **CR** 0 (XP 0 or 10; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +4 to hit, reach 5 ft. 1 Piercing damage.

