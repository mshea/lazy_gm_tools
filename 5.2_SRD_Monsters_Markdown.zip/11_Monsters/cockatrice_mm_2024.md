# Cockatrice

*Small Monstrosity, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 22 (5d6 + 5)
- **Speed:** 20 ft., Fly 40 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 6 | -2 | -2 |
| DEX | 12 | +1 | +1 |
| CON | 12 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 13 | +1 | +1 |
| CHA | 5 | -3 | -3 |

- **Immunities**: Petrified
- **Senses**: darkvision 60 ft.; Passive Perception 11
- **CR** 1/2 (XP 100; PB +2)

## Actions

***Petrifying Bite.*** *Melee Attack Roll:* +3, reach 5 ft. 3 (1d4 + 1) Piercing damage. If the target is a creature, it is subjected to the following effect. *Constitution Saving Throw*: DC 11. *First Failure* The target has the Restrained condition. The target repeats the save at the end of its next turn if it is still Restrained, ending the effect on itself on a success. *Second Failure* The target has the Petrified condition, instead of the Restrained condition, for 24 hours.

