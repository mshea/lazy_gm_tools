# Ogre

*Large Giant, Chaotic Evil*

- **Armor Class:** 11
- **Hit Points:** 68 (8d10 + 24)
- **Speed:** 40 ft.
- **Initiative**: -1 (9)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 19 | +4 | +4 |
| DEX | 8 | -1 | -1 |
| CON | 16 | +3 | +3 |
| INT | 5 | -3 | -3 |
| WIS | 7 | -2 | -2 |
| CHA | 7 | -2 | -2 |

- **Gear** Greatclub, Javelin x 3
- **Senses**: darkvision 60 ft.; Passive Perception 8
- **Languages**: Common, Giant
- **CR** 2 (XP 450; PB +2)

## Actions

***Greatclub.*** *Melee Attack Roll:* +6, reach 5 ft. 13 (2d8 + 4) Bludgeoning damage.

***Javelin.*** *Melee or Ranged Attack Roll:* +6, reach 5 ft. or range 30/120 ft. 11 (2d6 + 4) Piercing damage.

