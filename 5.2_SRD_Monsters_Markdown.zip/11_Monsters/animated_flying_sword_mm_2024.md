# Animated Flying Sword

*Small Construct, Unaligned*

- **Armor Class:** 17
- **Hit Points:** 14 (4d6)
- **Speed:** 5 ft., Fly 50 ft. (hover)
- **Initiative**: +4 (14)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 12 | +1 | +1 |
| DEX | 15 | +2 | +4 |
| CON | 11 | +0 | +0 |
| INT | 1 | -5 | -5 |
| WIS | 5 | -3 | -3 |
| CHA | 1 | -5 | -5 |

- **Immunities**: Poison, Psychic; Charmed, Deafened, Exhaustion, Frightened, Paralyzed, Petrified, Poisoned
- **Senses**: blindsight 60 ft.; Passive Perception 7
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Slash.*** *Melee Attack Roll:* +4, reach 5 ft. 6 (1d8 + 2) Slashing damage.

