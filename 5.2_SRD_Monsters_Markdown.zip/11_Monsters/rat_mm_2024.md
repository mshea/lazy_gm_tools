# Rat

*Small Beast, Unaligned*

- **Armor Class:** 10
- **Hit Points:** 1 (1d4 - 1)
- **Speed:** 20 ft., Climb 20 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 2 | -4 | -4 |
| DEX | 11 | +0 | +0 |
| CON | 9 | -1 | -1 |
| INT | 2 | -4 | -4 |
| WIS | 10 | +0 | +0 |
| CHA | 4 | -3 | -3 |

- **Skills**: Perception +2
- **Senses**: darkvision 30 ft.; Passive Perception 12
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Agile.*** The rat doesn't provoke Opportunity Attacks when it moves out of an enemy's reach.


## Actions

***Bite.*** *Melee Attack Roll:* +2, reach 5 ft. 1 Piercing damage.

