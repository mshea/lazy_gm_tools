# Black Bear

*Medium Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 19 (3d8 + 6)
- **Speed:** 30 ft., Climb 30 ft., Swim 30 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 15 | +2 | +2 |
| DEX | 12 | +1 | +1 |
| CON | 14 | +2 | +2 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +5
- **Senses**: darkvision 60 ft.; Passive Perception 15
- **CR** 1/2 (XP 100; PB +2)

## Actions

***Multiattack.*** The bear makes two Rend attacks.

***Rend.*** *Melee Attack Roll:* +4, reach 5 ft. 5 (1d6 + 2) Slashing damage.

