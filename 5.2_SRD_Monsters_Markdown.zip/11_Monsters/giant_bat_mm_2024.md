# Giant Bat

*Large Beast, Unaligned*

- **Armor Class:** 13
- **Hit Points:** 22 (4d10)
- **Speed:** 10 ft., Fly 60 ft.
- **Initiative**: +3 (13)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 15 | +2 | +2 |
| DEX | 16 | +3 | +3 |
| CON | 11 | +0 | +0 |
| INT | 2 | -4 | -4 |
| WIS | 12 | +1 | +1 |
| CHA | 6 | -2 | -2 |

- **Senses**: blindsight 120 ft.; Passive Perception 11
- **CR** 1/4 (XP 50; PB +2)

## Actions

***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. 6 (1d6 + 3) Piercing damage.

