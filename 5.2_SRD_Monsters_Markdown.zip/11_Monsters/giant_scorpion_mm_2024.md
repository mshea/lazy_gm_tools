# Giant Scorpion

*Large Beast, Unaligned*

- **Armor Class:** 15
- **Hit Points:** 52 (7d10 + 14)
- **Speed:** 40 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 16 | +3 | +3 |
| DEX | 13 | +1 | +1 |
| CON | 15 | +2 | +2 |
| INT | 1 | -5 | -5 |
| WIS | 9 | -1 | -1 |
| CHA | 3 | -4 | -4 |

- **Senses**: blindsight 60 ft.; Passive Perception 9
- **CR** 3 (XP 700; PB +2)

## Actions

***Multiattack.*** The scorpion makes two Claw attacks and one Sting attack.

***Claw.*** *Melee Attack Roll:* +5, reach 5 ft. 6 (1d6 + 3) Bludgeoning damage. If the target is a Large or smaller creature, it has the Grappled condition (escape DC 13) from one of two claws.

***Sting.*** *Melee Attack Roll:* +5, reach 5 ft. 7 (1d8 + 3) Piercing damage plus 11 (2d10) Poison damage.

