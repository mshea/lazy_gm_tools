# Crab

*Small Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 3 (1d4 + 1)
- **Speed:** 20 ft., Swim 20 ft.
- **Initiative**: +0 (10)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 6 | -2 | -2 |
| DEX | 11 | +0 | +0 |
| CON | 12 | +1 | +1 |
| INT | 1 | -5 | -5 |
| WIS | 8 | -1 | -1 |
| CHA | 2 | -4 | -4 |

- **Skills**: Stealth +2
- **Senses**: blindsight 30 ft.; Passive Perception 9
- **CR** 0 (XP 0 or 10; PB +2)

## Traits

***Amphibious.*** The crab can breathe air and water.


## Actions

***Claw.*** *Melee Attack Roll:* +2, reach 5 ft. 1 Bludgeoning damage.

