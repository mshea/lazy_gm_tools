# Noble

*Small Humanoid, Neutral*

- **Armor Class:** 15
- **Hit Points:** 9 (2d8)
- **Speed:** 30 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 11 | +0 | +0 |
| DEX | 12 | +1 | +1 |
| CON | 11 | +0 | +0 |
| INT | 12 | +1 | +1 |
| WIS | 14 | +2 | +2 |
| CHA | 16 | +3 | +3 |

- **Skills**: Deception +5, Insight +4, Persuasion +5
- **Gear** Breastplate, Rapier
- **Senses**: Passive Perception 12
- **Languages**: Common plus two other languages
- **CR** 1/8 (XP 25; PB +2)

## Actions

***Rapier.*** *Melee Attack Roll:* +3, reach 5 ft. 5 (1d8 + 1) Piercing damage.

