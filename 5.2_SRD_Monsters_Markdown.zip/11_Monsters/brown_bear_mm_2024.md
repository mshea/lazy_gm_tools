# Brown Bear

*Large Beast, Unaligned*

- **Armor Class:** 11
- **Hit Points:** 22 (3d10 + 6)
- **Speed:** 40 ft., Climb 30 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 17 | +3 | +3 |
| DEX | 12 | +1 | +1 |
| CON | 15 | +2 | +2 |
| INT | 2 | -4 | -4 |
| WIS | 13 | +1 | +1 |
| CHA | 7 | -2 | -2 |

- **Skills**: Perception +3
- **Senses**: darkvision 60 ft.; Passive Perception 13
- **CR** 1 (XP 200; PB +2)

## Actions

***Multiattack.*** The bear makes one Bite attack and one Claw attack.

***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. 7 (1d8 + 3) Piercing damage.

***Claw.*** *Melee Attack Roll:* +5, reach 5 ft. 5 (1d4 + 3) Slashing damage. If the target is a Large or smaller creature, it has the Prone condition.

