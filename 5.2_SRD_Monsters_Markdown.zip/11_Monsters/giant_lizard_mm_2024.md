# Giant Lizard

*Large Beast, Unaligned*

- **Armor Class:** 12
- **Hit Points:** 19 (3d10 + 3)
- **Speed:** 40 ft., Climb 40 ft.
- **Initiative**: +1 (11)

|STAT|SCORE|MOD|SAVE|
| --- | --- | --- | ---- |
| STR | 15 | +2 | +2 |
| DEX | 12 | +1 | +3 |
| CON | 13 | +1 | +1 |
| INT | 2 | -4 | -4 |
| WIS | 10 | +0 | +0 |
| CHA | 5 | -3 | -3 |

- **Senses**: darkvision 60 ft.; Passive Perception 10
- **CR** 1/4 (XP 50; PB +2)

## Traits

***Spider Climb.*** The lizard can climb difficult surfaces, including along ceilings, without needing to make an ability check.


## Actions

***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. 6 (1d8 + 2) Piercing damage.

